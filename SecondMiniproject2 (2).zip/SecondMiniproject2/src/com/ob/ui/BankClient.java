package com.ob.ui;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.ob.dtobean.AccountMaster;
import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.Payee;
import com.ob.dtobean.ServiceTracker;
import com.ob.dtobean.Transaction;
import com.ob.exception.OnlineBankingException;
import com.ob.service.IOnlineBankingService;
import com.ob.service.OnlineBankingService;

public class BankClient {
	 static Scanner sc=null;
	 static IOnlineBankingService serobj;
	 static CustomerSignUp csu=null;
	 static int openingBalance=0;
	 static List<Payee> payeelist=null;
	public BankClient() {
		serobj=new OnlineBankingService();
		csu=new CustomerSignUp();
	}
	
	//*************************************************  Main program *****************************************/
	
	public static void main(String[] args) throws OnlineBankingException, SQLException {		
		sc=new Scanner(System.in);
		/* do while loop for infity  */
		PropertyConfigurator.configure("resources/log4j.properties");
        Logger log = Logger.getRootLogger();
		
		System.out.println("**********WELCOME TO ABC BANK***********");
		System.out.println("                                         ");
		System.out.println("          1.Account Holder              ");
		System.out.println("          2.Admin                       ");
		System.out.println("****************************************");
		System.out.println("Enter your option:");
		 int option=sc.nextInt();
		 int loginId=0;
switch (option) {
//*************************ACCOUNTHOLDER***************************************************
      case 1:
			log.info(option);
			int payer_account=0;
			int accountBal = 0;
			int accountId=0;
			System.out.println("1.SignIn");
		    System.out.println("2.Signup");
			System.out.println("Enter your choice:");
			 int choice=sc.nextInt();
			 //boolean result=true;
			  switch (choice) {
	//***************ACCOUNTHOLDER SIGNIN****************************************************		   
			    case 1:
				log.info(choice);
				serobj=new OnlineBankingService();
				
				System.out.println("Login id:");
				
				  loginId=serobj.validateCredentials();

				System.out.println("PLEASE SELECT THE SERVICES");
				System.out.println("1.ACCOUNT BALANCE");
				System.out.println("2.ADDRESS CHANGE REQUEST");
				System.out.println("3.MOBILE NO. CHANGE REQUEST");
				System.out.println("4.CHEQUE BOOK REQUEST");
				System.out.println("5.SERVICE REQUEST TRACKER");
				System.out.println("6.FUND TRANSFER");
				System.out.println("7.CHANGE PASSWORD");				
				int custoption=sc.nextInt();				
				String newAddress=null;
				String newMobileNum=null;
				String checkBookDesc=null;
							switch (custoption) 
							{
//**********************FOR OBTAINING BALANCE********************************************							
							case 1:
								System.out.println("bal");
								//System.out.println(loginId);
								serobj=new OnlineBankingService();
							    int account_balance=serobj.customerOpeningBalance(loginId);
								System.out.println("YOUR ACCOUNT BALANCE  :  "+account_balance);
								break;
//**********************UPDATING ADDRESS**************************************************		
					 case 2:
					        	int status1=0;
					        	System.out.println("ENTER YOUR NEW ADDRESS");
					        	newAddress=sc.next();
					        	serobj=new OnlineBankingService();
					          status1=serobj.request(loginId,newAddress);
					          
					        	if(status1>=0) {
					        		System.out.println(status1 +" address updated");
					        	}
					        	else
					        		System.out.println("not inserted");
						        //System.out.println("REQUEST PROCESSED");
						        break;
	//******************UPDATING MOBILE NUMBER***************************************					        
					        case 3:int sta=0;
					        	System.out.println("ENTER YOUR NEW MOBILE NUMBER");
					        	newMobileNum=sc.next();
					        	serobj=new OnlineBankingService();
					        	 sta=serobj.request1(loginId,newMobileNum);
					        	if(sta>=0) {
					        		System.out.println("mobile number updated");
					        	}
					        	else
					        		System.out.println("mobile number is not  updated");
					           
					  
						
						        break;
	//******************** REQUEST FOR CHEQUE BOOK******************************************					        
					        case 4:int acctId;					        	
					        	   serobj=new OnlineBankingService();
					              
					               checkBookDesc="NEW CHEQUEBOOK";
					        	   int result=serobj.serviceTrackerId(loginId,checkBookDesc);
					        	   if(result>0) {
						           System.out.println("REQUEST PROCESSED");
					        	   System.out.println("Your Service ID is: "+result);
					        	   }
					        	   else
					        		   System.out.println("REQUEST NOT PROCESSED");
						
						        break;
//**************************SERVICE TRACKING************************************************						        
					        case 5:
					        	
					        	serobj=new OnlineBankingService();
					        	String status6=null;
					        	int servId=0;
					        	System.out.println("Enter Service id to see the service status");
						        servId=sc.nextInt();
						        status6=serobj.retrieveServiceTrackerByAccountId(servId);
						        if(status6!=null) {
						        	System.out.println("your status of service is : "+status6);
						        }
						        else {
						        	System.out.println("No service is active");
						        }
						        break;
  //**************************FUND TRANSFER************************************************					        
					        case 6: 
					        	
					        	payer_account=serobj.retriveAccountId(loginId);
					        	System.out.println("payer account number: "+payer_account);
					        	int status7=0;
						        List<Payee> payeelist=serobj.retrivePayeeDetails(payer_account);         /*       from payee table       */
					       	 for(Payee p:payeelist) {
					       		 System.out.println(p);
					       	 }
					       	System.out.println("WELCOME TO THE PAYMENT SERVICES");
							System.out.println("1 ---> SEND MONEY");
							System.out.println("2 ---> MANAGE BENEFICIARY");
							System.out.println("Enter your required service");
							int a=0;
							do {
							String option1=sc.next();
							switch (option1) {
							case "1":
								System.out.println("Welcome to the SEND MONEY service");			
								try {
									a=3;
									  List<Payee> payeelist1=serobj.retrivePayeeDetails(payer_account);         /*       from payee table       */
								       	 for(Payee p:payeelist1) {
								       		 System.out.println(p);
								       	
								       	 }		
						    	 System.out.println("ENTER THE PAYEE ACCOUNT ID"+"\n"+"Fund Transfer is available only for registered Beneficiary");
						    	 int payeeaccountid=sc.nextInt();	
						    	 
						    	 for(Payee l:payeelist) {	    		
						    		 if(payeeaccountid==l.getPayeeAccId()) {	    			
						    			 fundTransfer(payer_account,payeeaccountid);
						    		 }
						    	 }
						    	 
						    	 int count=0;
						    	 for(Payee k:payeelist) {
						    	  if( (payeeaccountid!=k.getAccountId()) && (count==payeelist.size()) ){
						    		  addNewBeneficiary(payer_account);	 
						    		  fundTransfer(payer_account,payeeaccountid);
						    	 }
						    	 }
						    	 
								}catch(NullPointerException e) {
						 			System.err.println("");
						 		}
								
								break;
								
							case "2":
								
								System.out.println("Welcome to the MANAGE BENEFICIARY service");
								System.out.println(" 1 ---> Add Beneficiary ");
								System.out.println(" 2 ---> Beneficiary Details");
								int b=0;
								do {
								String manageOption=sc.next();
								switch (manageOption) {
								case "1":
									addNewBeneficiary(payer_account);				
									break;
									
								case "2":
									
									
									beneficiaryDetails(loginId);
									 	
									break;

								default:
									System.err.println("INVALID CHOICE. ");
									System.err.println("chances left "+(2-b));
									if(b<2) {
										System.err.println("Please enter again.");
									}
									if((2-b)==0) {
										System.err.println("Please login again.You exceed the maximum limit.");
									}
									b++;
									
									break;
								}
								}while(b<3);
								a=3;
								break;
								
								
							default:
								System.err.println("INVALID CHOICE. ");
								System.err.println("chances left "+(2-a));
								if(a<2) {
									System.err.println("Please enter again.");
								}
								if((2-a)==0) {
									System.err.println("Please login again.You exceed the maximum limit.");
								}
								a++;
								
								break;
							}
							}while(a<3);
					     
					      	 
						        break;
	//********************** UPDATING PASSWORD  ******************************					     
					       
					       case 7:
					    	int staus8=0;
					       	System.out.println("CHANGE PASSWORD FOR USERLOGIN");
					       	int count=0;
					    	int acid=0;
					    	String loginPassword;
					      
					       	System.out.println("ENTER YOUR ACCOUNT ID");
					       	acid=sc.nextInt();		       
					       		
					       		System.out.println("ENTER NEW PASSWORD");
					       	    loginPassword=sc.next();		
					       	 serobj=new OnlineBankingService();
								int status8=serobj.updateLoginPassword(acid,loginPassword);
								if(status8>=0) {
									System.out.println("password updated");
								}
								else {
									System.out.println("password is not updated");
								}
					       	
					       	}
			           break;
						
//***********************CUSTOMER SIGNUP**************************************	       
				
			     case 2: 
					
		           System.out.println("SIGN UP");
					String custsignup=sc.nextLine();
					customerSignUp();
					
					break;
                   }
			  
			  break;

// *************************ADMIN LOGIN*************************************			
		case 2:
						 	System.out.println("ENTER YOUR USERID");
							int adminuserid=sc.nextInt();
							
							System.out.println("ENTER YOUR PASSWORD");
							String adminpassword=sc.next();
						
							if((adminuserid==1234) && (adminpassword.equals("admin"))) 							
							administrationLogin();							
							
							else 
								System.out.println("ENTER VALID LOGIN DETAILS");							
							
							break;
			default:
		   System.out.println("Enter Valid details");
		   break;
	}

}
	
	//*************************ADMIN OPERATIONS******************************
	private static void administrationLogin() throws SQLException, OnlineBankingException {
		System.out.println("PLEASE SELECT THE SERVICES");
		System.out.println("1.CREATE NEW ACCOUNT");
		System.out.println("2.VIEW TRANSACTION");
		int adminoption=sc.nextInt();
//*********************         ADMIN ACCOUNT CREATION*****************************************************		
		Boolean result=true;		
		String mobileNo;
		String eMail;
		int openingBalance;
		String panCard;
		String accountType;
		serobj=new OnlineBankingService();
		switch (adminoption) {
		case 1:				
			System.out.println("PLEASE ENTER  DETAILS");
			String name;
			do {
			System.out.println("ENTER YOUR NAME ");
		     name=sc.next();
			
			}while(serobj.validatename(name)==false);
			
			System.out.println("ENTER ADDRESS DETAILS");
			String addressDetails=sc.next();
		
			do {
			System.out.println("ENTER MOBILE NUMBER");
			mobileNo=sc.next();
			
			}while(serobj.validatemobileNo(mobileNo)==false);
			
		do {
			System.out.println("ENTER EMAIL ID");
			 eMail=sc.next();
			
		}while(serobj.validateEMail(eMail)==false);
			
		do {
			System.out.println("OPENING BALANCE");
		 openingBalance=sc.nextInt();
			
		}while(serobj.validateOpeningBalance(openingBalance)==false);
		
		do {
			System.out.println("ENTER pan card");
			 panCard=sc.next();
			
		}while(serobj.validatePanCard(panCard)==false);
			
		do {
			System.out.println("enter account type");
			 accountType=sc.next();
			serobj.validateAccountType(accountType);
		}while(serobj.validateAccountType(accountType)==false);
			
			
			int accountId=0;
			NewAccount newAccount= new NewAccount(accountId, name, eMail,mobileNo, addressDetails, accountType, openingBalance, panCard);
		
			int result1=addinfo(newAccount);		
			if(result1>0)
			{
				System.out.println("WELCOME TO ABC BANK");
				System.out.println("Your account Id is: "+result1);
			}
			
			
			break;
        
//***************************VIEW TRANSACTIONS*****************************************************		  
      case 2:
        	System.out.println("enter value to see the transaction details ");
        	System.out.println(" 1.FOR 1 DAY ");
        	System.out.println(" 2.FOR 1 MONTH ");
        	System.out.println(" 3.FOR 1 YEAR ");
        	System.out.println(" 4.ALL TRANSACTION");
        	int choice1=sc.nextInt();
        	switch (choice1) {
 // ***************************VIEW DAY WISE TRANSACTIONS*****************************************************	      	
        	case 1:
        		System.out.println("Enter the day to get transaction");
			       String day=sc.next();
			       List<Transaction> finList2= new ArrayList<>();
					finList2 = getDayTransactions(day);
					for (Transaction tran : finList2) {
						System.out.println(tran);
					}
break;
// ***************************VIEW MONTH WISE TRANSACTIONS*****************************************************
            case 2:
				 System.out.println("enter the month to get tran");
			       int month=sc.nextInt();
			       System.out.println("enter year");
			       int year1=sc.nextInt();
			       List<Transaction> finList= new ArrayList<>();
				
						finList = getMonthlyTransactions(month,year1);
						for (Transaction tran : finList) {
							System.out.println(tran);
						}
						
				break;
// ***************************VIEW YEAR WISE TRANSACTIONS*****************************************************
			 case 3:
				System.out.println("enterr the year to get tran");
			       int year=sc.nextInt();
			       List<Transaction> finList3= new ArrayList<>();
					
					finList3 = getYearlyTransactions(year);
					for (Transaction tran : finList3) {
						System.out.println(tran);
					}
			       
               break;
 // ***************************VIEW ALL TRANSACTIONS*****************************************************               
			 case 4:
				List<Transaction> finList1=null;
				
					finList1 = retrieveAllTranInfo();			
			
				for(Transaction tran:finList1)
				{
				System.out.println(tran);	
				}
			     
            break;
			default:
				break;
			}   	
				
		}
	
		
	}
	private static List<Transaction> getYearlyTransactions(int year) throws SQLException {
		serobj=new OnlineBankingService();
		return serobj.getYearlyTransactions(year);
	}
	private static List<Transaction> getDayTransactions(String day) throws SQLException {
		serobj=new OnlineBankingService();
	
		return serobj.getDayTransactions(day);
		
	}
	private static List<Transaction> getMonthlyTransactions(int month, int year1) throws SQLException {
		serobj=new OnlineBankingService();
		return serobj.getMonthlyTransactions(month,year1);
	}
	private static List<Transaction> retrieveAllTranInfo() throws SQLException {
		serobj=new OnlineBankingService();
		return serobj.retrieveAllTranInfo() ;
	}
	private static int addinfo(NewAccount newAccount) throws OnlineBankingException {
		serobj=new OnlineBankingService();
		return serobj.addinfo(newAccount);
	}
		
	
	
	
	
public static void customerSignUp() throws OnlineBankingException {
		
		 csu=new CustomerSignUp();
		 serobj=new OnlineBankingService();
		
		System.out.println("ENTER THE ACCOUNT ID");
		int accountId=sc.nextInt();
		csu.setAccountId(accountId);
		
		System.out.println("CREATE USER Id");
		int userId=sc.nextInt();
		csu.setUserId(userId);
		
		System.out.println("CREATE PASSWORD");
		String loginPassword=sc.next();
		csu.setLoginPassword(loginPassword);
		
		System.out.println("SECRET QUESTION --> WHEN DO YOU GET HIGH ?");
		String secretQuestion=sc.next();
		csu.setSecretQuestion(secretQuestion);
		
		System.out.println("CREATE TRANSACTION PASSWORD");
		String transactionPassword=sc.next();
		csu.setTransactionPassword(transactionPassword);
		
		System.out.println("CREATE LOCK STATUS ****************************");
		String lockStatus=sc.next();
		csu.setLockStatus(lockStatus);
		int out=serobj.customerSignUp(csu);
		if(out>0) {
			System.out.println("data is inserterd");
		}
}
		
public static void fundTransfer(int payer_account,int payeeaccountid) throws OnlineBankingException{
	
	
	int acc_bal=150000;
	String transpwd=null;
	System.out.println("ENTER THE TRANSACTION PASSWORD");
	transpwd=sc.next();                 
	String usertransactionpwd=serobj.retrivetransactionpwd(payer_account);
	
	
	if((transpwd).equals(usertransactionpwd)&&transpwd!=null) {

		System.out.println("ENTER THE AMOUNT");
		int transactionAmount=sc.nextInt(); 
	    int count=0;
	          do {
		            if(transactionAmount< acc_bal) {
                          
                    count=3;
	                int transaction_id=(int)(Math.random()*1000000);
	                System.out.println("ENTER THE TRANSACTION DESCRIPTION");
	                String transdesc=sc.next();
	                System.out.println("SELECT THE TRANSACTION TYPE");
	                System.out.println(" 1  --->  NEFT");
	                System.out.println(" 2  --->  RTGS");
	                System.out.println(" 3  --->  IMPS");
	                String choice=sc.next();
	
	switch (choice) {
	case "1":
		serobj.updatetransaction(transaction_id,transdesc,transactionAmount,payeeaccountid,"NEFT");    /*  to transaction table  AND fund transfer table */  
		serobj.updatepayeeaccountbal(payeeaccountid,transactionAmount);                                  /*   to account master    */
		serobj.updatepayeraccountbal(payer_account,transactionAmount);                                /*    to account master     */
		serobj.fundTransfer(transaction_id,payer_account,payeeaccountid,transactionAmount);   /*  to fund transfer table */
		System.out.println("NEFT TRANSACTION SUCCESSFUL");
		break;
	case "2":
		serobj.updatetransaction(transaction_id,transdesc,transactionAmount,payeeaccountid,"RTGS");              
		serobj.updatepayeeaccountbal(payeeaccountid,transactionAmount);
		serobj.updatepayeraccountbal(payer_account,transactionAmount);
		serobj.fundTransfer(transaction_id,payer_account,payeeaccountid,transactionAmount);
		System.out.println("RTGS TRANSACTION SUCCESSFUL");
		break;
	case "3":
		serobj.updatetransaction(transaction_id,transdesc,transactionAmount,payeeaccountid,"IMPS");          
		serobj.updatepayeeaccountbal(payeeaccountid,transactionAmount);
		serobj.updatepayeraccountbal(payer_account,transactionAmount);
		serobj.fundTransfer(transaction_id,payer_account,payeeaccountid,transactionAmount);
		System.out.println("IMPS TRANSACTION SUCCESSFUL");
		break;
	default:
		System.out.println("INVALID CHOICE . PLEASE ENTER CORRECT OPTION");
		break;
	               }
    }else{
	        count++;
	        System.out.println("YOUR ACCOUNT BALANCE IS INSUFFICIENT TO MAKE TRANSACTION");
            System.out.println("ENTER THE AMOUNT AGAIN");
	     }	
	}while(count<3);
	}else {
		System.out.println("ENTERED WRONG TRANSACTION PASSWORD");
	}

}
public static List<Payee> beneficiaryDetails(int loginId) throws OnlineBankingException {
	serobj=new OnlineBankingService();
	int payer_account=serobj.retriveAccountId(loginId);
	System.out.println(" Beneficiary Details :");
	List<Payee> payeelist2=null;
	try {
		payeelist2 = serobj.retrivePayeeDetails(payer_account);
		System.out.println(payer_account);
		if(payeelist2.size()==0) {
			System.out.println("No Beneficiary added");
		}
	} catch (OnlineBankingException|NullPointerException e) {
		System.out.println("No Beneficiary Added.");
	}       

    for(Payee p:payeelist2) {
	 	    System.out.println(p);
	}	
    return payeelist2;
}

public static void addNewBeneficiary(int payer_account) throws OnlineBankingException {
	 System.out.println(" ADD NEW BENEFICIARY ");
	 int d=0;
	 do {
	 System.out.println("ENTER THE PAYEE ACCOUNT ID");
	 int payeeAccountId=sc.nextInt();
	 int result=0;
	try {
		result = serobj.checkpayeeAccountId( payeeAccountId);
	} catch (NullPointerException e) {
		System.out.println("");
	}   
	 
	    if(result>0) {
	    	d=3;
	        System.out.println("ENTER NICKNAME");
	        String nickname=sc.next();
	         
	      /*     status should be pending*/
	        /*  pin should be send to reg mobile number */  
		        
	        int status=0;
			try {
				status = serobj.storepayeeDetails(payer_account,payeeAccountId,nickname);
			} catch (OnlineBankingException e) {
				
				System.out.println("entered wrong account id");
			}   
	 
	             if(status>0) {
		              System.out.println("data enter successfully");
	             }else {
		              System.out.println("data not entered");
	             }
	   }else {
		   d++;
		   System.err.println("WRONG ACCOUNT ID IS ENTERED"+"\n"+"chances left "+(3-d));
		   
	   }
	 }while(d<3);
	
}
	}



