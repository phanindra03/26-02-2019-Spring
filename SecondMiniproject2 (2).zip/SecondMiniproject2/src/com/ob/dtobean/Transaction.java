package com.ob.dtobean;

import java.sql.Date;

public class Transaction {
	private int transactionId;
	private String transactionDesc;
	private Date dateOfTransaction;
	private String transactionType;
	private int transactionAmount;
	private long accountNO;

	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionDesc() {
		return transactionDesc;
	}
	public void setTransactionDesc(String transactionDesc) {
		this.transactionDesc = transactionDesc;
	}
	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}
	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public int getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(int transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public long getAccountNO() {
		return accountNO;
	}
	public void setAccountNO(long accountNO) {
		this.accountNO = accountNO;
	}
	@Override
	public String toString() {
		return "Tran [transactionId=" + transactionId + ", transactionDesc=" + transactionDesc + ", dateOfTransaction="
				+ dateOfTransaction + ", transactionType=" + transactionType + ", transactionAmount=" + transactionAmount
				+ ", accountNO=" + accountNO + "]";
	}
	public Transaction(int transactionId, String transactionDesc, Date dateOfTransaction, String transactionType,
			int transactionAmount, long accountNO) {
		super();
		this.transactionId = transactionId;
		this.transactionDesc = transactionDesc;
		this.dateOfTransaction = dateOfTransaction;
		this.transactionType = transactionType;
		this.transactionAmount = transactionAmount;
		this.accountNO = accountNO;
	}
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}


}
