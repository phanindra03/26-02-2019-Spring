package com.ob.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.ob.dtobean.AccountMaster;
import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.Payee;
import com.ob.dtobean.ServiceTracker;
import com.ob.dtobean.Transaction;
import com.ob.exception.OnlineBankingException;
import com.ob.util.DBUtil;

//********************************STARTING OF DAO LAYER**************************************************//
public class OnlineBankingDao implements IOnlineBankingDao{
	Connection conn=null;
	CustomerSignUp customersignup = null;
	AccountMaster newAccount =null;
	ServiceTracker serviceTracker=null;
	  Scanner sc = new Scanner(System.in);
	  
//*************************************Retrive Payee Details***********************************************//
	  @Override
		public List<Payee> retrivePayeeDetails(int accountId) throws OnlineBankingException {
			PropertyConfigurator.configure("resources/log4j.properties");
			Logger log=Logger.getRootLogger();
			
			List<Payee> payeeList=null;
			
			try {
				
				PreparedStatement pst=conn.prepareStatement(IQueryMapper.RETRIVE_PAYEE_ID);
				
				pst.setInt(1, accountId);
				ResultSet rs=pst.executeQuery();
				payeeList=new ArrayList<Payee>();
				Payee payee=null;
				
				while(rs.next())
				{
					payee=new Payee(rs.getInt(1),rs.getString(2) );
					payeeList.add(payee);
					
			    } 
			}
			
			catch (SQLException|NullPointerException e) 
			{
			
				throw new OnlineBankingException("Data can't be retrieved"+e.getMessage());
			}
			return payeeList;
			
		}

//************************Store Payee Details*******************************************************//
		@Override
		public int storepayeeDetails(int accountId, int payeeAccountId, String nickname) throws OnlineBankingException {
			PropertyConfigurator.configure("resources/log4j.properties");
			Logger log=Logger.getRootLogger();
			conn=DBUtil.DbConnection();
			int status=0;
			
			try {
				PreparedStatement pst=conn.prepareStatement(IQueryMapper.PAYEE_INSERT_QRY);
				pst.setInt(1,accountId);	
				pst.setInt(2,payeeAccountId);
				pst.setString(3, nickname);
				status=pst.executeUpdate();
				 
				} catch (SQLException e) {
			log.error("payee data is not stored:: "+e.getMessage());
					
				throw new OnlineBankingException("data not stored "+e.getMessage());
			}
			
			return status;
		}

//***********************Update Payee Account Balance******************************************//
		@Override
		public void updatepayeeaccountbal(int payeeaccountid,int transactionAmount) throws OnlineBankingException{
			PropertyConfigurator.configure("resources/log4j.properties");
			Logger log=Logger.getRootLogger();
			conn=DBUtil.DbConnection();
			
			int accountbalance=0;
			try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.RETRIVE_ACCOUNT_BAL);
	        pst.setInt(1,payeeaccountid);
	        ResultSet rs= pst.executeQuery();        
	           while(rs.next()) {
	        	   accountbalance=rs.getInt(1);
	        	  
	           }
			}catch(SQLException e) {
			log.error(" data not retrive "+e.getMessage());
				
				throw new OnlineBankingException("data not retrive "+e.getMessage());
			}
			int status=0;
			try {
				PreparedStatement pst=conn.prepareStatement(IQueryMapper.UPDATE_PAYEE_ACCOUNTBAL);
				pst.setInt(1,accountbalance-transactionAmount);	
				pst.setInt(2,payeeaccountid);
				
				status=pst.executeUpdate();
				 
				} catch (SQLException e) {
				log.error("payee data is not stored:: "+e.getMessage());
					
				throw new OnlineBankingException("data not stored "+e.getMessage());
			}
			if(status>0) {
				log.info("balance updated");
			}else {
				log.info("balance not updated ");
			}
			
			
		}

//***********************Update payer Account Balance************************************************//
		@Override
		public void updatepayeraccountbal(int accountId,int transactionAmount) throws OnlineBankingException {
			PropertyConfigurator.configure("resources/log4j.properties");
			Logger log=Logger.getRootLogger();
			conn=DBUtil.DbConnection();
			
			int accountbalance=0;
			try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.RETRIVE_ACCOUNT_BAL);
	        pst.setInt(1,accountId);
	        ResultSet rs= pst.executeQuery();        
	           while(rs.next()) {
	        	   accountbalance=rs.getInt(1);       
	           }
			}catch(SQLException e) {
			log.error(" data not retrive "+e.getMessage());
				
				throw new OnlineBankingException("data not retrive "+e.getMessage());
			}
			int status=0;
			try {
				PreparedStatement pst=conn.prepareStatement(IQueryMapper.UPDATE_PAYER_ACCOUNTBAL);
				pst.setInt(1,accountbalance+transactionAmount);	
				pst.setInt(2,accountId);
				
				
				status=pst.executeUpdate();
				 
				} catch (SQLException e) {
			log.error("payee data is not stored:: "+e.getMessage());
					
				throw new OnlineBankingException("data not stored "+e.getMessage());
			}
			if(status>0) {
			log.info("balance updated");
				
			}else {
				log.info("balance not updated ");
			}
			
			
		}

//*********************Fund Transfer*************************************************************//
		@Override
		public void fundTransfer(int transaction_id, int accountId, int payeeaccountid, int transactionAmount) throws OnlineBankingException {
			
			PropertyConfigurator.configure("resources/log4j.properties");
			Logger log=Logger.getRootLogger();
			conn=DBUtil.DbConnection();
			int status=0;
			
			try {
				PreparedStatement pst=conn.prepareStatement(IQueryMapper.INSERT_FUND_TRANSFER);
				pst.setInt(1,transaction_id);	
				pst.setInt(2,accountId);
				pst.setInt(3,payeeaccountid);
				pst.setInt(4,transactionAmount);
				
				status=pst.executeUpdate();
				 
				} catch (SQLException e) {
				log.error("payee data is not stored:: "+e.getMessage());
				System.out.println("DATA NOT ENTERED ");
				throw new OnlineBankingException("data not stored "+e.getMessage());
			}
			if(status>0) {
				log.info("DATA ENTERED SUCCESSFULLY");
			}else {
				log.info("DATA NOT ENTERED ");
			}
		
			
		}

//*********************Retrieve Transaction Password***********************/
		@Override
		public String retrivetransactionpwd(int accountId) throws OnlineBankingException {
			PropertyConfigurator.configure("resources/log4j.properties");
			Logger log=Logger.getRootLogger();
			conn=DBUtil.DbConnection();
			List<Payee> payeeList=null;
			String transactionpwd=null;
			
			try {
				PreparedStatement pst = conn.prepareStatement(IQueryMapper.RETRIVE_TRANSACTION_PWD);
	            pst.setInt(1,accountId);
	            ResultSet rs= pst.executeQuery();        
	               while(rs.next()) {
	            	    transactionpwd=rs.getString(1);       
	               }
			    }catch (SQLException e) 
			    {
			    	log.error("payee data is not stored:: "+e.getMessage());
				     throw new OnlineBankingException("Data can't be retrieved"+e.getMessage());
			    }
		
			return  transactionpwd;
			
			
			
		}

	//*******************CheckpayeeAccountId*********************/
		@Override
		public int checkpayeeAccountId(int payeeAccountId) throws OnlineBankingException {
			PropertyConfigurator.configure("resources/log4j.properties");
			Logger log=Logger.getRootLogger();
			conn=DBUtil.DbConnection();
			int count=0;
			try {
				
				 PreparedStatement ps = conn.prepareStatement(IQueryMapper.RETRIVE_PAYEE_ACCOUNTID);
				ps.setInt(1,payeeAccountId);
			    ResultSet resultSet = ps.executeQuery();
				if(resultSet.next()) {
				    count = resultSet.getInt(1);
				}
			}
			catch (SQLException e) 
			{
				log.error("payee data is not stored:: "+e.getMessage());
				throw new OnlineBankingException("Data can't be retrieved"+e.getMessage());
			}
			return count;
		}

	//**********************Update Transaction*************************/
		@Override
		public void updatetransaction(int transaction_id, String transdesc, int transactionAmount, int payeeaccountid,
				String string) throws OnlineBankingException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
			conn=DBUtil.DbConnection();
			int status=0;
			
			try {
				PreparedStatement pst=conn.prepareStatement(IQueryMapper.INSERT_TRANSACTION);
				pst.setInt(1,transaction_id);	
				pst.setString(2,transdesc);
				pst.setString(3, string);
				pst.setInt(4,transactionAmount);
				pst.setInt(5,payeeaccountid);
				status=pst.executeUpdate();
				 
				} catch (SQLException e) {
				log.error("payee data is not stored:: "+e.getMessage());
					System.out.println("DATA NOT ENTERED ");
				throw new OnlineBankingException("data not stored "+e.getMessage());
			}
			if(status>0) {
				log.info("DATA ENTERED SUCCESSFULLY  update trans");
			}else {
				log.error("payee data is not stored:: ");
				
			}
		
			
			
			
		}


	//******************************* NEW CustomerSignUp*******************************************************
	
	public int customerSignUp(CustomerSignUp customersignup) throws OnlineBankingException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
		int status=0;
	   
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.Usertable_INSERT_QRY);
			pst.setLong(1,customersignup.getAccountId());
			pst.setInt(2,customersignup.getUserId());
			pst.setString(3, customersignup.getLoginPassword());
			pst.setString(4, customersignup.getSecretQuestion());
			pst.setString(5, customersignup.getTransactionPassword());
			pst.setString(6,customersignup.getLockStatus());
		
			status=pst.executeUpdate();
			
			log.info(status+" data is inserted");
		}catch (SQLException e) {
			log.error("data is not stored:: "+e.getMessage());
			throw new OnlineBankingException("data not stored "+e.getMessage());
		} 
		return status;
		}
    
//******************************UpdateLoginPassword*************************//
	@Override
	public int updateLoginPassword(int userid, String loginPassword) throws OnlineBankingException {
		System.out.println();
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
		int status=0;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.Update_PASSWORD);
			pst.setString(1, loginPassword);
			pst.setInt(2, userid);
			
			status=pst.executeUpdate();
			log.info(status+" data is inserted");
		}catch (SQLException e) {
			log.error("data is not stored:: "+e.getMessage());
			throw new OnlineBankingException("data not stored "+e.getMessage());
		}
		return status;
		
		
	}
//****************************CustomerSignUp BY USER ID AND PASSWORD FOR RETRIVING DETAILS*****************************//	
    @Override
	public CustomerSignUp validateCustomerLoginDetails(int custuserid, String custpassword) throws OnlineBankingException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
	
		int status=0;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.RETRIVE_BY_UserID_QRY);
			pst.setInt(1, custuserid);
			pst.setString(2, custpassword);
			ResultSet rs=pst.executeQuery();
			if(rs.next()) {
			customersignup=new CustomerSignUp(rs.getLong(1), rs.getInt(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));
			System.out.println(customersignup);
			}
			
			log.info(status+" data is inserted");
		}catch (SQLException e) {
			log.error("data is not stored:: "+e.getMessage());
			throw new OnlineBankingException("data not stored "+e.getMessage());
		}
		return customersignup;
	}
    
 //************************************RetrieveServiceTrackerByAccountId*******************************************//
    @Override
	public String retrieveServiceTrackerByAccountId(int accountId) throws OnlineBankingException {
		conn=DBUtil.DbConnection();
		
		String servStatus=null;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.RETRIVE_BY_ServiceTrackerID_QRY);
			pst.setInt(1,accountId);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
			servStatus=rs.getString(1);
			}
		} catch (SQLException e) {
			throw new OnlineBankingException("couldn't retrieve data from db  "+e.getMessage());
		}
		
		return servStatus;
	}
		
//**********************************Address change Request*********************************//
	@Override
	public int request(int acc_id, String description) throws OnlineBankingException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
	    int status=0;
		long accountIdRetrieved=0;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.Dummy_Query);
			pst.setLong(1,acc_id);
			ResultSet rs=pst.executeQuery();
			 if(rs.next()) {
				 accountIdRetrieved = rs.getLong(1);
			}
			 System.out.println("AcNo:"+accountIdRetrieved);
			PreparedStatement pst1=conn.prepareStatement(IQueryMapper.CUSTOMER_update_Qry);			
			pst1.setString(1, description);			
			pst1.setLong(2, accountIdRetrieved);				
			status=pst1.executeUpdate();
			System.out.println(status);
			log.info(status+" data is inserted");
		    }catch (SQLException e) 
		      {
			log.error("data is not updated:: "+e.getMessage());
			
			throw new OnlineBankingException("data not stored "+e.getMessage());
		      }
		
		return status;
	}

//**********************************ServiceTrackerId Request*********************************//
	@Override
	public int serviceTrackerId(int accountId,String newCheck) throws OnlineBankingException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
		long accountIdRetrieved1=0;
		int statusServ=0;
		int serviceId=0;
		String serviceStatus="active";
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.Dummy_Query);
			pst.setLong(1,accountId);
			ResultSet rs=pst.executeQuery();
			 if(rs.next()) {
				 accountIdRetrieved1 = rs.getLong(1);
				 System.out.println(accountIdRetrieved1);
			}
			PreparedStatement pst1=conn.prepareStatement(IQueryMapper.ServiceTracker_INSERT_QRY);
			pst1.setString(1, newCheck);
			pst1.setLong(2, accountIdRetrieved1);
			pst1.setString(3, serviceStatus);			
			statusServ=pst1.executeUpdate();
			System.out.println(statusServ);
			PreparedStatement pst2=conn.prepareStatement(IQueryMapper.SELECT_SERVICE_TRACKING_ID);
			 ResultSet rs1=pst2.executeQuery();
			 if(rs1.next())
			 {
				serviceId=rs1.getInt(1);	
				System.out.println(serviceId);
				log.info(serviceId);
			 }
			
			log.info(statusServ+" data is inserted");
		}catch (SQLException e) {
			log.error("data is not stored:: "+e.getMessage());
			System.out.println("catch");
			throw new OnlineBankingException("data not stored "+e.getMessage());
		}
		return serviceId;
	}
//********************************CustomerOpeningBalance*********************************************//
	@Override
	public int customerOpeningBalance(int loginId) throws OnlineBankingException {
		
	PropertyConfigurator.configure("resources/log4j.properties");
				Logger log=Logger.getRootLogger();
				conn=DBUtil.DbConnection();
				
				int status=0;
				int accbal=0;
				long accountIdRetrieved = 0;
				try {
					PreparedStatement pst=conn.prepareStatement(IQueryMapper.Dummy_Query);
					pst.setLong(1,loginId);
					ResultSet rs=pst.executeQuery();
					 if(rs.next()) {
						 accountIdRetrieved = rs.getLong(1);
						 System.out.println(accountIdRetrieved);
					 }
					
					PreparedStatement pst1=conn.prepareStatement(IQueryMapper.RETRIVE_BY_OPENINGBAL_QRY);
					pst1.setLong(1,accountIdRetrieved);
					
					 ResultSet rs1=pst1.executeQuery();
					 if(rs1.next())
					 {
					
					    accbal=rs1.getInt(1);
					    System.out.println(accbal);
						log.info(newAccount);
					 }
					log.info(status+" data is inserted");
				}catch (SQLException e) {
					log.error("data is not stored:: "+e.getMessage());
					throw new OnlineBankingException("data not stored "+e.getMessage());
				}
				
				return accbal;
			}

//***********************************CUSTOMER_MOBILE NUMBER UPDATE********************************//
	@Override
	public int request1(int accountId, String description) throws OnlineBankingException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
	     int status1=0;
		long accountIdRetrieved=0;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.Dummy_Query);
			pst.setLong(1,accountId);
			ResultSet rs=pst.executeQuery();
			 if(rs.next()) {
				 accountIdRetrieved = rs.getLong(1);				
			 }
			
			 PreparedStatement pst1=conn.prepareStatement(IQueryMapper.CUSTOMER_mobileupdate_Qry);			
			pst1.setString(1, description);
	        pst1.setLong(2, accountIdRetrieved);
			status1=pst1.executeUpdate();
	        log.info(status1+" data is inserted");
		    }catch (SQLException e) 
		      {
			log.error("data is not updated:: "+e.getMessage());
			
			throw new OnlineBankingException("data not stored "+e.getMessage());
		      }
		
		return status1;
	}

//*************************************REQUEST FOR CHEQUE BOOK**************************//
	@Override
	public int Request3(int accountId, String description) throws OnlineBankingException {
		
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
		int status=0;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.ServiceTracker_INSERT_QRY);
			pst.setInt(1, accountId);
			status=pst.executeUpdate();
			log.info(status+" data is inserted");
		}catch (SQLException e) {
			log.error("data is not stored:: "+e.getMessage());
			throw new OnlineBankingException("data not stored "+e.getMessage());
		}
		return status;
	}

//**********************************************MONTHLY TRANSACTIONS********************************************//
	@Override
	public List<Transaction> getMonthlyTransactions(int month,int year1) throws SQLException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		Transaction t=null;
		conn=DBUtil.DbConnection();
		List<Transaction> mon=new ArrayList<>();
	    PreparedStatement pst1=conn.prepareStatement(IQueryMapper.retrieve_month);
	    pst1.setInt(1,month);
	    pst1.setInt(2, year1);
	    ResultSet rs=pst1.executeQuery();
	    while(rs.next())
	    	
	    {
	    	
	    	t=new Transaction(rs.getInt(1), rs.getString(2), rs.getDate(3), rs.getString(4), rs.getInt(5),rs.getLong(6)); 
	    	 mon.add(t);
	    }   
	    return mon;
	}
	
//********************************YEARLY TRANSACTIONS***********************************//

	@Override
	public List<Transaction> getYearlyTransactions(int year) throws SQLException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		Transaction t=null;
		conn=DBUtil.DbConnection();
		List<Transaction> mon=new ArrayList<>();
	    PreparedStatement pst1=conn.prepareStatement(IQueryMapper.retrieve_year);
	    pst1.setInt(1,year);		
	    ResultSet rs=pst1.executeQuery();
	    
	    while(rs.next())
	    	
	    {
	    
	    	t=new Transaction(rs.getInt(1), rs.getString(2), rs.getDate(3), rs.getString(4), rs.getInt(5),rs.getLong(6)); 
	    	 mon.add(t);
	    }   
	    return mon;
	
	}
//*******************************RETRIEVE ALL TRANSACTIONS**********************************************//

	@Override
	public List<Transaction> retrieveAllTranInfo() throws SQLException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		Transaction t=null;
		conn=DBUtil.DbConnection();
		List<Transaction> mon=new ArrayList<>();
	    PreparedStatement pst3=conn.prepareStatement(IQueryMapper.retrieveall);
	  		
	    ResultSet rs=pst3.executeQuery();
	    
	    while(rs.next())
	    	
	    	
	    {
	    	
	    	t=new Transaction(rs.getInt(1), rs.getString(2), rs.getDate(3), rs.getString(4), rs.getInt(5),rs.getLong(6)); 
	    	 mon.add(t);
	    }   
	    return mon;
	}



//**************************NEW ACCOUNT CREATION***********************************************//
	@Override
	public int addinfo(NewAccount newAccount) throws OnlineBankingException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
		int status=0;
		int accountId=0;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.insert_qry);
			pst.setString(1,newAccount.getCustomerName());
			pst.setString(2, newAccount.getCustomerAddress()); 
			pst.setString(3,newAccount.getCustomerMobNum());
			pst.setString(4, newAccount.getCustomerEmail());
			pst.setString(5,newAccount.getAccountType());
			pst.setInt(6, newAccount.getOpeningBalance()); 
			pst.setString(7, newAccount.getPancard());

			status=pst.executeUpdate();
			log.info(status+" data is inserted");
			
			PreparedStatement	pst1=conn.prepareStatement(IQueryMapper.RETRIVE_BY_AccountID_QRY);
			 ResultSet rs1=pst1.executeQuery();
			 if(rs1.next())
			 {
				accountId=rs1.getInt(1);
				log.info(accountId);
			 }
			} catch (SQLException e) {
			log.error("data is not stored:: "+e.getMessage());
			throw new OnlineBankingException("data not stored "+e.getMessage());
		}return accountId;
		
	}

//***************************GET ONE DAY TRANSCATIONS********************************************//
	@Override
	public List<Transaction> getDayTransactions(String day) throws SQLException {
		Transaction t=null;
		conn=DBUtil.DbConnection();
		List<Transaction> mon=new ArrayList<>();
	    PreparedStatement pst1=conn.prepareStatement(IQueryMapper.retrieve_day);
	    pst1.setString(1,day);
	 
	    ResultSet rs=pst1.executeQuery();
	    
	    while(rs.next()) 		
	    {
	    	t=new Transaction(rs.getInt(1), rs.getString(2), rs.getDate(3), rs.getString(4), rs.getInt(5),rs.getLong(6)); 
	    	 mon.add(t);
	    }   
	    return mon;
	}



//*****************************CustomerSignUp FOR RETRIVING THE ID ***********************//	
	public  CustomerSignUp validateCredentials(int id) throws OnlineBankingException {
		
		String password=null;
		CustomerSignUp credentialsBean=null;
		try{
			
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
		
		PreparedStatement pst=conn.prepareStatement(IQueryMapper.VALIDATE_CREDENTIALS);
		pst.setInt(1, id);
		ResultSet rs=pst.executeQuery();
		
		if(rs.next()) {
			credentialsBean=new CustomerSignUp(rs.getInt(2), rs.getString(3));
		}
		
		System.out.println(rs.getInt(2));
		System.out.println(rs.getString(3));
		
		}
		catch(SQLException se){
		throw new OnlineBankingException("out of boundary couldnot catch" + se.getMessage());	
		}
		
		
		
		
		return credentialsBean;
		
	}

//******************RetriveAccountId*********************************//
	@Override
	public int retriveAccountId(int loginId) throws OnlineBankingException {
		conn=DBUtil.DbConnection();
		int accountId=0;
		try{
			PreparedStatement ps=conn.prepareStatement(IQueryMapper.RETRIVE_ACCOUNTID);
			ps.setInt(1, loginId);
			ResultSet resultrs=ps.executeQuery();
			if(resultrs.next()){
				accountId=resultrs.getInt(1);
				
			}
			}
			catch(SQLException e){
				throw new OnlineBankingException("out of boundary couldnot catch" );
			}
		
		return accountId;
	}
	
	
	
	
	}

//****************************************END OF THE DAO LAYER***********************************//

	

