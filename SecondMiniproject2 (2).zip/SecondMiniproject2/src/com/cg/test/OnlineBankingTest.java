package com.cg.test;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.ob.dao.IOnlineBankingDao;
import com.ob.dao.OnlineBankingDao;
import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.Transaction;
import com.ob.exception.OnlineBankingException;
import com.ob.util.DBUtil;


public class OnlineBankingTest {
	DBUtil dbc=null;
	Connection conn=null;
	IOnlineBankingDao obdao=null;
	 CustomerSignUp customer =null;
	 NewAccount newAccount=null;
	@Before
	public void init()
	{
		 conn=DBUtil.DbConnection();
	}
	@Test
	public void checkConn(){
		Connection conn=DBUtil.DbConnection();
		Assert.assertNotNull(conn);
	}
	@After
	public void destroy()
	{
		conn=null;
	}
	@Before
	public void init1()
	{
	    obdao	 =new OnlineBankingDao();
	customer = new CustomerSignUp(1234, "admin", "18-05-1996", "admin","y");
	}
	@Test
	public void checkCustomerSignUp() throws OnlineBankingException
	{
		int returnUserId=obdao.customerSignUp(customer);
		Assert.assertEquals(1, returnUserId);
	}
	
	@After
	public void destroy1()
	{
		obdao=null;
	}
	@Before
	public void init2() {
		obdao	 =new OnlineBankingDao();
		 newAccount = new NewAccount(1234, "raju", "raju@gmail.com", "8197453675", "kphb", "savings", 1000, "CXCPP7022");
	}
	@Test
	public void checkNewAccount() throws OnlineBankingException {
		int returnAccountId = obdao.addinfo(newAccount);
		Assert.assertEquals(123456792, returnAccountId);
	}
	@After
	public void destroy2()
	{
		obdao=null;
	}
	 //admin testing
	  @Test
	  public void getDayTest() throws SQLException
	  {
	   List<Transaction> list=obdao.getDayTransactions("25-feb-2019");
	   Assert.assertNotNull(list);
	   
	  }
	  @Test
	  public void getMonthTest() throws SQLException
	  {
	   List<Transaction> list=obdao.getMonthlyTransactions(2,2019);
	   Assert.assertNotNull(list);
	   
	  }

	 @Test
	  public void getYearTest() throws SQLException
	  {
	   List<Transaction> list=obdao.getYearlyTransactions(2019);
	   Assert.assertNotNull(list);
	   
	  }

	 @Test
	  public void getAllTest() throws SQLException
	  {
	   List<Transaction> list=obdao.retrieveAllTranInfo();
	   Assert.assertNotNull(list);
	   
	  }


}
